Workman keyboard layout for Kinesis keyboard
===========

Kinesis Corporation was founded in February 1991 with the objective of developing a computer keyboard optimized for comfort and productivity.

Provided mapping files compatible with [Advantage](https://www.kinesis-ergo.com/shop/advantage2-qd/) keyboards family. They might work with other Kinesis products.



## Installation

* Follow [manufacturer manual](https://www.kinesis-ergo.com/support/technical-support/manuals-drivers/) to remap QWERTY or DVORAK layout to Workman
