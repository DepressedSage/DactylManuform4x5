Workman-PKL
===========

Workman-PKL implements Workman and Workman for Programmers (Workman-P) keyboard layouts for the Portable Keyboard Layout program. Portable Keyboard Layout (PKL) is an open source software program that allows you to use different keyboard layouts in Windows without having to install them. It can be run directly from a USB flash drive or any other portable medium.

Workman-PKL has been tested to work with PKL version 0.3.

In order to add Workman layouts to your PKL installation extract "workman" and "workman-p" folders from this archive into "Portable Keyboard Layout\layouts" and specify the layout you wish to use in "pkl.ini".

The keyboard layout itself, as well as this implementation, are in the Public Domain.


## Portable Keyboard Layout

Required download: http://pkl.sourceforge.net/