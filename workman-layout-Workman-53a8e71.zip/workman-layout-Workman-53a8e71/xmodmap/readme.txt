Go directory where you have unpacked Workman
Type: setxkbmap us; xmodmap xmodmap/xmodmap.workman && xset r 66
To switch back to QWERTY type: setxkbmap us; xset -r 66
